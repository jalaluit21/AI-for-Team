document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('promptForm');
    const responseDiv = document.getElementById('response');
    const suggestionsDiv = document.getElementById('suggestions');

    form.addEventListener('submit', async (event) => {
        event.preventDefault();
        const prompt = form.elements.prompt.value;

        try {
            const response = await fetch('/get_response', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ prompt })
            });

            const data = await response.json();

            if (data.error) {
                responseDiv.innerHTML = `Error: ${data.error}`;
            } else {
                responseDiv.innerHTML = `<p>Response:</p> ${data.response}`;
                await fetchSuggestions(data.response);
            }
        } catch (error) {
            console.error('Error:', error);
            responseDiv.innerHTML = `Error: ${error.message}`;
        }
    });

    function fetchSuggestions(responseText) {
        return fetch('/get_suggestions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ prompt: responseText })
        })
        .then(response => response.json())
        .then(suggestionsData => {
            displaySuggestions(suggestionsData.suggestions);
        })
        .catch(error => {
            console.error('Error fetching suggestions:', error);
        });
    }

    function displaySuggestions(suggestions) {
        suggestionsDiv.innerHTML = `<p>Suggestions:</p> <ul>`;
        for (const suggestion of suggestions) {
            suggestionsDiv.innerHTML += `<li>${suggestion}</li>`;
        }
        suggestionsDiv.innerHTML += `</ul>`;
    }

    suggestionsDiv.addEventListener('click', (event) => {
        if (event.target.tagName === 'LI') {
            form.elements.prompt.value = event.target.innerText;
            form.submit();
        }
    });
});

// other scripte

        function sendMessage() {
            const userMessage = document.getElementById('messageInput').value;
            if (userMessage.trim() !== '') {
                appendMessage('user', userMessage);

                // Check if the message is an image URL
                if (isImageURL(userMessage)) {
                    appendImage('chatGPT', userMessage);
                    document.getElementById('messageInput').value = '';
                    return;
                }

                // Send the question to Flask to get the response
                fetch('/get_response', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'prompt=' + encodeURIComponent(userMessage),
                })
                .then(response => response.json())
                .then(data => {
                    const chatGPTResponse = data.response;
                    appendMessage('chatGPT', chatGPTResponse);
                })
                .catch(error => console.error('Error:', error));

                // Clear the input field
                document.getElementById('messageInput').value = '';
            }
        }

        function appendMessage(sender, message) {
            const messageDiv = document.createElement('div');
            messageDiv.classList.add('message', sender === 'user' ? 'userMessage' : 'chatGPTMessage');
            messageDiv.innerHTML = `<p>${message}</p>`;
            document.getElementById('chat').appendChild(messageDiv);

            // Scroll down to see the last message
            document.getElementById('chat').scrollTop = document.getElementById('chat').scrollHeight;
        }

        function appendImage(sender, imageURL) {
            const imageDiv = document.createElement('div');
            imageDiv.classList.add('message', 'imageMessage', sender === 'user' ? 'userMessage' : 'chatGPTMessage');
            imageDiv.innerHTML = `<img src="${imageURL}" alt="Image">`;
            document.getElementById('chat').appendChild(imageDiv);

            // Scroll down to see the last message
            document.getElementById('chat').scrollTop = document.getElementById('chat').scrollHeight;
        }

        function isImageURL(url) {
            // A simple check for a URL ending with an image extension
            return /\.(jpeg|jpg|gif|png)$/.test(url);
        }

        function handleKeyPress(event) {
            if (event.key === 'Enter') {
                sendMessage();
            }
        }

