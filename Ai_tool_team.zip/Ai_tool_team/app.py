from flask import Flask, request, render_template, jsonify
import openai
import os

app = Flask(__name__)
openai.api_key=(" YOUR KEY AI HERE")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/get_response', methods=['POST'])
def get_response():
    prompt = request.form['prompt']
    try:
        response = openai.Completion.create(engine="text-davinci-003", prompt=prompt, max_tokens=1024)
        return jsonify({"response": response.choices[0].text})
    except Exception as e:
        return jsonify({"error": str(e)})

@app.route('/get_suggestions', methods=['POST'])
def get_suggestions():
    prompt = request.form['prompt']
    try:
        response = openai.Completion.create(engine="text-davinci-004", prompt=prompt, max_tokens=1024)
        suggestions = [choice.text for choice in response.choices if choice.text != response.choices[0].text]
        return jsonify({"suggestions": suggestions})
    except Exception as e:
        return jsonify({"error": str(e)})

if __name__ == '__main__':
    app.run()